--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.17
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sys_development;
--
-- Name: sys_development; Type: DATABASE; Schema: -; Owner: marc
--

CREATE DATABASE sys_development WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE sys_development OWNER TO marc;

\connect sys_development

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: active_admin_comments; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.active_admin_comments (
    id integer NOT NULL,
    namespace character varying,
    body text,
    resource_type character varying,
    resource_id integer,
    author_type character varying,
    author_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.active_admin_comments OWNER TO marc;

--
-- Name: active_admin_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.active_admin_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.active_admin_comments_id_seq OWNER TO marc;

--
-- Name: active_admin_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.active_admin_comments_id_seq OWNED BY public.active_admin_comments.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO marc;

--
-- Name: batch_types; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.batch_types (
    id integer NOT NULL,
    name character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.batch_types OWNER TO marc;

--
-- Name: batch_types_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.batch_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.batch_types_id_seq OWNER TO marc;

--
-- Name: batch_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.batch_types_id_seq OWNED BY public.batch_types.id;


--
-- Name: batches; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.batches (
    id integer NOT NULL,
    name character varying,
    batch_type_id integer,
    description text,
    passagenb integer,
    patientnb character varying,
    clonenb character varying,
    user_id integer,
    vial_nb integer,
    culture character varying,
    corrected boolean,
    technique character varying
);


ALTER TABLE public.batches OWNER TO marc;

--
-- Name: batches_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.batches_id_seq OWNER TO marc;

--
-- Name: batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.batches_id_seq OWNED BY public.batches.id;


--
-- Name: box_types; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.box_types (
    id integer NOT NULL,
    name character varying,
    max_position integer,
    comment text,
    vertical_max integer,
    horizontal_max integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.box_types OWNER TO marc;

--
-- Name: box_types_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.box_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.box_types_id_seq OWNER TO marc;

--
-- Name: box_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.box_types_id_seq OWNED BY public.box_types.id;


--
-- Name: boxes; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.boxes (
    id integer NOT NULL,
    name character varying,
    barcode character varying,
    box_type_id integer,
    rack_position_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    comment text,
    recap text,
    team_id integer,
    color_id integer,
    container_name character varying,
    shelf_name character varying,
    shelf_rack_name character varying
);


ALTER TABLE public.boxes OWNER TO marc;

--
-- Name: boxes_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.boxes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.boxes_id_seq OWNER TO marc;

--
-- Name: boxes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.boxes_id_seq OWNED BY public.boxes.id;


--
-- Name: colors; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.colors (
    id integer NOT NULL,
    name character varying,
    code character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.colors OWNER TO marc;

--
-- Name: colors_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.colors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.colors_id_seq OWNER TO marc;

--
-- Name: colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.colors_id_seq OWNED BY public.colors.id;


--
-- Name: container_types; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.container_types (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE public.container_types OWNER TO marc;

--
-- Name: container_types_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.container_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.container_types_id_seq OWNER TO marc;

--
-- Name: container_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.container_types_id_seq OWNED BY public.container_types.id;


--
-- Name: containers; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.containers (
    id integer NOT NULL,
    name character varying,
    barcode character varying,
    location_id integer,
    container_type_id integer,
    recap text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.containers OWNER TO marc;

--
-- Name: containers_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.containers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.containers_id_seq OWNER TO marc;

--
-- Name: containers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.containers_id_seq OWNED BY public.containers.id;


--
-- Name: options; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.options (
    id integer NOT NULL,
    display_all boolean DEFAULT true,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.options OWNER TO marc;

--
-- Name: options_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.options_id_seq OWNER TO marc;

--
-- Name: options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.options_id_seq OWNED BY public.options.id;


--
-- Name: positions; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.positions (
    id integer NOT NULL,
    name character varying,
    box_id integer,
    nb integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.positions OWNER TO marc;

--
-- Name: positions_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.positions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.positions_id_seq OWNER TO marc;

--
-- Name: positions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.positions_id_seq OWNED BY public.positions.id;


--
-- Name: rack_positions; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.rack_positions (
    id integer NOT NULL,
    name character varying,
    shelf_rack_id integer,
    nb integer,
    available boolean DEFAULT true,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.rack_positions OWNER TO marc;

--
-- Name: rack_positions_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.rack_positions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rack_positions_id_seq OWNER TO marc;

--
-- Name: rack_positions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.rack_positions_id_seq OWNED BY public.rack_positions.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO marc;

--
-- Name: shelf_racks; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.shelf_racks (
    id integer NOT NULL,
    name character varying,
    shelf_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.shelf_racks OWNER TO marc;

--
-- Name: shelf_racks_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.shelf_racks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shelf_racks_id_seq OWNER TO marc;

--
-- Name: shelf_racks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.shelf_racks_id_seq OWNED BY public.shelf_racks.id;


--
-- Name: shelves; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.shelves (
    id integer NOT NULL,
    name character varying,
    container_id integer,
    rack_number integer,
    rack_position_number integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.shelves OWNER TO marc;

--
-- Name: shelves_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.shelves_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shelves_id_seq OWNER TO marc;

--
-- Name: shelves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.shelves_id_seq OWNED BY public.shelves.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.teams (
    id integer NOT NULL,
    name character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.teams OWNER TO marc;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teams_id_seq OWNER TO marc;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: teams_users; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.teams_users (
    id integer NOT NULL,
    team_id integer,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.teams_users OWNER TO marc;

--
-- Name: teams_users_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.teams_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teams_users_id_seq OWNER TO marc;

--
-- Name: teams_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.teams_users_id_seq OWNED BY public.teams_users.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    firstname character varying,
    lastname character varying,
    username character varying,
    role character varying,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    recap text
);


ALTER TABLE public.users OWNER TO marc;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO marc;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vials; Type: TABLE; Schema: public; Owner: marc
--

CREATE TABLE public.vials (
    id integer NOT NULL,
    name character varying,
    volume double precision,
    comment text,
    batch_id integer,
    "out" boolean DEFAULT false,
    barcode character varying,
    position_id integer,
    recap text,
    exit_date date,
    freezing_date date,
    user_id integer
);


ALTER TABLE public.vials OWNER TO marc;

--
-- Name: vials_id_seq; Type: SEQUENCE; Schema: public; Owner: marc
--

CREATE SEQUENCE public.vials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vials_id_seq OWNER TO marc;

--
-- Name: vials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: marc
--

ALTER SEQUENCE public.vials_id_seq OWNED BY public.vials.id;


--
-- Name: active_admin_comments id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.active_admin_comments ALTER COLUMN id SET DEFAULT nextval('public.active_admin_comments_id_seq'::regclass);


--
-- Name: batch_types id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.batch_types ALTER COLUMN id SET DEFAULT nextval('public.batch_types_id_seq'::regclass);


--
-- Name: batches id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.batches ALTER COLUMN id SET DEFAULT nextval('public.batches_id_seq'::regclass);


--
-- Name: box_types id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.box_types ALTER COLUMN id SET DEFAULT nextval('public.box_types_id_seq'::regclass);


--
-- Name: boxes id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.boxes ALTER COLUMN id SET DEFAULT nextval('public.boxes_id_seq'::regclass);


--
-- Name: colors id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.colors ALTER COLUMN id SET DEFAULT nextval('public.colors_id_seq'::regclass);


--
-- Name: container_types id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.container_types ALTER COLUMN id SET DEFAULT nextval('public.container_types_id_seq'::regclass);


--
-- Name: containers id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.containers ALTER COLUMN id SET DEFAULT nextval('public.containers_id_seq'::regclass);


--
-- Name: options id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.options ALTER COLUMN id SET DEFAULT nextval('public.options_id_seq'::regclass);


--
-- Name: positions id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.positions ALTER COLUMN id SET DEFAULT nextval('public.positions_id_seq'::regclass);


--
-- Name: rack_positions id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.rack_positions ALTER COLUMN id SET DEFAULT nextval('public.rack_positions_id_seq'::regclass);


--
-- Name: shelf_racks id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.shelf_racks ALTER COLUMN id SET DEFAULT nextval('public.shelf_racks_id_seq'::regclass);


--
-- Name: shelves id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.shelves ALTER COLUMN id SET DEFAULT nextval('public.shelves_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: teams_users id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.teams_users ALTER COLUMN id SET DEFAULT nextval('public.teams_users_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vials id; Type: DEFAULT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.vials ALTER COLUMN id SET DEFAULT nextval('public.vials_id_seq'::regclass);


--
-- Data for Name: active_admin_comments; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.active_admin_comments (id, namespace, body, resource_type, resource_id, author_type, author_id, created_at, updated_at) FROM stdin;
\.
COPY public.active_admin_comments (id, namespace, body, resource_type, resource_id, author_type, author_id, created_at, updated_at) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: batch_types; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.batch_types (id, name, created_at, updated_at) FROM stdin;
\.
COPY public.batch_types (id, name, created_at, updated_at) FROM '$$PATH$$/3362.dat';

--
-- Data for Name: batches; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.batches (id, name, batch_type_id, description, passagenb, patientnb, clonenb, user_id, vial_nb, culture, corrected, technique) FROM stdin;
\.
COPY public.batches (id, name, batch_type_id, description, passagenb, patientnb, clonenb, user_id, vial_nb, culture, corrected, technique) FROM '$$PATH$$/3366.dat';

--
-- Data for Name: box_types; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.box_types (id, name, max_position, comment, vertical_max, horizontal_max, created_at, updated_at) FROM stdin;
\.
COPY public.box_types (id, name, max_position, comment, vertical_max, horizontal_max, created_at, updated_at) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: boxes; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.boxes (id, name, barcode, box_type_id, rack_position_id, created_at, updated_at, comment, recap, team_id, color_id, container_name, shelf_name, shelf_rack_name) FROM stdin;
\.
COPY public.boxes (id, name, barcode, box_type_id, rack_position_id, created_at, updated_at, comment, recap, team_id, color_id, container_name, shelf_name, shelf_rack_name) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: colors; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.colors (id, name, code, created_at, updated_at) FROM stdin;
\.
COPY public.colors (id, name, code, created_at, updated_at) FROM '$$PATH$$/3360.dat';

--
-- Data for Name: container_types; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.container_types (id, name) FROM stdin;
\.
COPY public.container_types (id, name) FROM '$$PATH$$/3364.dat';

--
-- Data for Name: containers; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.containers (id, name, barcode, location_id, container_type_id, recap, created_at, updated_at) FROM stdin;
\.
COPY public.containers (id, name, barcode, location_id, container_type_id, recap, created_at, updated_at) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: options; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.options (id, display_all, user_id, created_at, updated_at) FROM stdin;
\.
COPY public.options (id, display_all, user_id, created_at, updated_at) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.positions (id, name, box_id, nb, created_at, updated_at) FROM stdin;
\.
COPY public.positions (id, name, box_id, nb, created_at, updated_at) FROM '$$PATH$$/3342.dat';

--
-- Data for Name: rack_positions; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.rack_positions (id, name, shelf_rack_id, nb, available, created_at, updated_at) FROM stdin;
\.
COPY public.rack_positions (id, name, shelf_rack_id, nb, available, created_at, updated_at) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: shelf_racks; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.shelf_racks (id, name, shelf_id, created_at, updated_at) FROM stdin;
\.
COPY public.shelf_racks (id, name, shelf_id, created_at, updated_at) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: shelves; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.shelves (id, name, container_id, rack_number, rack_position_number, created_at, updated_at) FROM stdin;
\.
COPY public.shelves (id, name, container_id, rack_number, rack_position_number, created_at, updated_at) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.teams (id, name, created_at, updated_at) FROM stdin;
\.
COPY public.teams (id, name, created_at, updated_at) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: teams_users; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.teams_users (id, team_id, user_id, created_at, updated_at) FROM stdin;
\.
COPY public.teams_users (id, team_id, user_id, created_at, updated_at) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.users (id, email, encrypted_password, firstname, lastname, username, role, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at, recap) FROM stdin;
\.
COPY public.users (id, email, encrypted_password, firstname, lastname, username, role, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at, recap) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: vials; Type: TABLE DATA; Schema: public; Owner: marc
--

COPY public.vials (id, name, volume, comment, batch_id, "out", barcode, position_id, recap, exit_date, freezing_date, user_id) FROM stdin;
\.
COPY public.vials (id, name, volume, comment, batch_id, "out", barcode, position_id, recap, exit_date, freezing_date, user_id) FROM '$$PATH$$/3338.dat';

--
-- Name: active_admin_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.active_admin_comments_id_seq', 1, false);


--
-- Name: batch_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.batch_types_id_seq', 10, true);


--
-- Name: batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.batches_id_seq', 195, true);


--
-- Name: box_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.box_types_id_seq', 2, true);


--
-- Name: boxes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.boxes_id_seq', 14, true);


--
-- Name: colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.colors_id_seq', 9, true);


--
-- Name: container_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.container_types_id_seq', 2, true);


--
-- Name: containers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.containers_id_seq', 1, true);


--
-- Name: options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.options_id_seq', 1, true);


--
-- Name: positions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.positions_id_seq', 1134, true);


--
-- Name: rack_positions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.rack_positions_id_seq', 396, true);


--
-- Name: shelf_racks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.shelf_racks_id_seq', 36, true);


--
-- Name: shelves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.shelves_id_seq', 3, true);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.teams_id_seq', 49, true);


--
-- Name: teams_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.teams_users_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: vials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: marc
--

SELECT pg_catalog.setval('public.vials_id_seq', 571, true);


--
-- Name: active_admin_comments active_admin_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.active_admin_comments
    ADD CONSTRAINT active_admin_comments_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: batch_types batch_types_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.batch_types
    ADD CONSTRAINT batch_types_pkey PRIMARY KEY (id);


--
-- Name: batches batches_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_pkey PRIMARY KEY (id);


--
-- Name: box_types box_types_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.box_types
    ADD CONSTRAINT box_types_pkey PRIMARY KEY (id);


--
-- Name: boxes boxes_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.boxes
    ADD CONSTRAINT boxes_pkey PRIMARY KEY (id);


--
-- Name: colors colors_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT colors_pkey PRIMARY KEY (id);


--
-- Name: container_types container_types_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.container_types
    ADD CONSTRAINT container_types_pkey PRIMARY KEY (id);


--
-- Name: containers containers_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.containers
    ADD CONSTRAINT containers_pkey PRIMARY KEY (id);


--
-- Name: options options_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.options
    ADD CONSTRAINT options_pkey PRIMARY KEY (id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: rack_positions rack_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.rack_positions
    ADD CONSTRAINT rack_positions_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: shelf_racks shelf_racks_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.shelf_racks
    ADD CONSTRAINT shelf_racks_pkey PRIMARY KEY (id);


--
-- Name: shelves shelves_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.shelves
    ADD CONSTRAINT shelves_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: teams_users teams_users_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.teams_users
    ADD CONSTRAINT teams_users_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vials vials_pkey; Type: CONSTRAINT; Schema: public; Owner: marc
--

ALTER TABLE ONLY public.vials
    ADD CONSTRAINT vials_pkey PRIMARY KEY (id);


--
-- Name: index_active_admin_comments_on_author_type_and_author_id; Type: INDEX; Schema: public; Owner: marc
--

CREATE INDEX index_active_admin_comments_on_author_type_and_author_id ON public.active_admin_comments USING btree (author_type, author_id);


--
-- Name: index_active_admin_comments_on_namespace; Type: INDEX; Schema: public; Owner: marc
--

CREATE INDEX index_active_admin_comments_on_namespace ON public.active_admin_comments USING btree (namespace);


--
-- Name: index_active_admin_comments_on_resource_type_and_resource_id; Type: INDEX; Schema: public; Owner: marc
--

CREATE INDEX index_active_admin_comments_on_resource_type_and_resource_id ON public.active_admin_comments USING btree (resource_type, resource_id);


--
-- Name: index_teams_users_on_team_id; Type: INDEX; Schema: public; Owner: marc
--

CREATE INDEX index_teams_users_on_team_id ON public.teams_users USING btree (team_id);


--
-- Name: index_teams_users_on_user_id; Type: INDEX; Schema: public; Owner: marc
--

CREATE INDEX index_teams_users_on_user_id ON public.teams_users USING btree (user_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: marc
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: marc
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- PostgreSQL database dump complete
--

